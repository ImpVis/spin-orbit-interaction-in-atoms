<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="4"  :hotspotColumnSize="hotspotWidth">
            <template #hotspots>
                <iv-pane position="left" format="push" :width=28>
                    <iv-sidebar-content :showPagination="true">                     
                        <!-- <iv-sidebar-section title="Theory" icon="microscope" >
                            <p>
                                For 
                            </p>
                        </iv-sidebar-section> -->
                        <iv-sidebar-section title="Instructions" icon="question" theme="Lime" >
                            <p>
                                In the settings tab, turn on/off different effects to see how they split and shift the 
                                atom's energy levels. 
                            </p>
                            <p>
                                Predict which quantum numbers will no longer be appropiate to use, and which
                                need to be introduced. Adjust these quantum numbers using the increment buttons to see 
                                the energy level they correspond to on the diagram.
                            </p>                           
                        </iv-sidebar-section>                                         
                    </iv-sidebar-content>
                </iv-pane>

                <iv-fixed-hotspot :noWastedSpace="true" position="topright" style=" z-index: 2;" >
                    <div>
                        <p> <b> SETTINGS </b></p>
                        
                        <div class="row">
                            <div class="column left"> <label for="fineToggle"> Fine splitting</label> </div>
                            <div class="column right" > <iv-toggle-basic id="fineToggle" :resetCapability="true" :value="false" @input="fineChange"> </iv-toggle-basic> </div>
                        </div>
                        <div v-show="fine == true">
                            <div class="row">
                                <div class="column left"><label for="lambToggle"> Lamb shift </label></div>
                                <div class="column right" > <iv-toggle-basic id="lambToggle" :value="false" @input="lambChange"> </iv-toggle-basic></div>
                            </div>
                            <div class="row">
                                <div class="column left"><label for="hyperfineToggle"> Hyperfine splitting </label></div>
                                <div class="column right" > <iv-toggle-basic id="hyperfineToggle" :value="false" @input="hyperfineChange"> </iv-toggle-basic></div>
                            </div>
                            <div class="row">
                                <div class="column left"><label for="zeemanToggle"> Zeeman splitting</label></div>
                                <div class="column right" > <iv-toggle-basic id="zeemanToggle" :value="false" @input="zeemanChange"> </iv-toggle-basic></div>
                            </div>
                        </div>

                        <div style="margin-top: 10px;" v-show="zeeman == true">
                            <iv-slider id="magSlider" @sliderChanged="magChange" theme="Lime" :bubble="false" :numTick="false" :name=sliderName :min="0" :max="0.2" :init_val="0.1" :step="0.002"/>
                            <span style="float:left; font-size:small;">Low</span>
                            <span class="sliderMax" style="float:right; font-size:small;">High</span>
                        </div>

                    </div>

                    <div> 
                        <p> <b> QUANTUM NUMBERS </b></p>
                        <div>
                            <label for="lButton"> l number </label>
                            <iv-increment-button id="lButton" @change="lChange" :initialValue="1" :maximum="2" :minimum="0" :increment="1"> </iv-increment-button>
                        </div>
                        <div v-show="fine == true">
                            <label for="jButton"> j number </label>
                            <iv-increment-button id="jButton" @change="jChange" :initialValue="jInit" :maximum="maxj" :minimum="minj" :increment="1"> </iv-increment-button>
                        </div>
                        <div v-show="zeeman == true && hyperfine==false">
                            <label for="mjButton"> m_j number </label>
                            <iv-increment-button id="mjButton" @change="mjChange" :initialValue=mjInit :maximum=mjMax :minimum=mjMin :increment="1"> </iv-increment-button>
                        </div>
                        <div v-show="hyperfine == true">
                            <label for="fButton"> F number </label>
                            <iv-increment-button id="fButton" @change="fChange" :initialValue=fInit :maximum=fMax :minimum=fMin :increment="1"> </iv-increment-button>
                        </div>
                        <div v-show="zeeman == true && hyperfine==true">
                            <label for="mfButton"> m_F number </label>
                            <iv-increment-button id="mfButton" @change="mfChange" :initialValue=mfInit :maximum=mfMax :minimum=mfMin :increment="1"> </iv-increment-button>
                        </div>
                        
                    </div>   

                    <div style="padding-top:25px;">
                        <iv-reset-button>Reset</iv-reset-button>
                    </div>

                </iv-fixed-hotspot>

            </template>
            
        
            <div class="iv-welcome-message">
                <div id="graph"></div>
            </div>
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js';
import Plotly from 'plotly.js/dist/plotly.min.js';
export default {
    name:"energysplit",
    data(){
        return {
            pageName:"Energy Splitting",
            hotspotWidth:"300px",
            vue_config,
            l:1,
            j:1/2,
            minj:1/2,
            maxj:3/2,
            mj:1/2,
            f:0,
            mf:1/2,
            mag:0.1,
            updateGraph:false,
            lamb:false,
            fine: false,
            hyperfine: false,
            zeeman: false,
        }
    },
    props:{
        jInit:{default: 1/2},
        jMax:{default: 3/2},
        jMin:{default: 1/2},
        mjInit:{default: 1/2},
        mjMax:{default: 3/2},
        mjMin:{default: 1/2},
        fInit:{default: 0},
        fMax:{default: 1},
        fMin:{default: 0},
        mfInit:{default: 1/2},
        mfMax:{default: 3/2},
        mfMin:{default: 1/2},
        sliderName:{default: "Magnetic field strength"},
    },
    methods:{
        lChange(e){
            this.l=e;
            if (this.l != 0){
                this.maxj= this.l+ 1/2;
                this.minj = this.l - 1/2;
            }
            else{
                this.maxj= 1/2;
                this.minj= 1/2;
            }
            this.updateGraph=true;
        },
        jChange(e){
            this.j=e;
            this.updateGraph=true;
        },
        mjChange(e){
            this.mj=e;
            this.updateGraph=true;
        },
        fChange(e){
            this.f=e;
            this.updateGraph=true;
        },
        mfChange(e){
            this.mf=e;
            this.updateGraph=true;
        },
        magChange(e){
            this.mag=e;
            this.updateGraph=true;
        },
        lambChange(e){
            this.lamb= !e;
            this.updateGraph=true;
        },
        fineChange(e){
            this.fine= !e;
            this.updateGraph=true;
        },
        hyperfineChange(e){
            this.hyperfine= !e;
            this.updateGraph=true;
        },
        zeemanChange(e){
            this.zeeman= !e;
            this.updateGraph=true;
        }

    },
    mounted(){
        let v=this;

        var data = [];
        const
        plt = {//layout of graph
            layout : {
                autosize: true,
                font: {
                    family: "Fira Sans",
                    size: 16,
                },
                xaxis: {
                    autorange: true,
                    showgrid: false,
                    zeroline: false,
                    showline: false,
                    autotick: true,
                    ticks: '',
                    showticklabels: false,
                },
                yaxis: {
                    autorange: false,
                    showgrid: false,
                    zeroline: false,
                    showline: false,
                    autotick: true,
                    ticks: '',
                    showticklabels: false,
                    range: [-0.5,12],
                },
                margin: {
                    l: 0, r: 0, b: 0, t: 0, pad: 0,
                },
                hovermode: false,
                annotations: [
                    {
                        x: 0.15,
                        y: 11,
                        xref: 'x',
                        yref: 'y',
                        text: '',
                        showarrow: true,
                        arrowhead: 3,
                        arrowcolor: '#7f7f7f',
                        ax: 0,
                        ay: 450
                    },
                    {
                        x: 0.08,
                        y: 5,
                        xref: 'x',
                        yref: 'y',
                        xanchor: 'center',
                        yanchor: 'center',
                        text: 'Energy',
                        font: {
                            family: "Fira Sans",
                            size: 26,
                            color: '#7f7f7f'
                        },
                        textangle: '-90',
                        showarrow: false
                    },
                    {
                        x: 0.25,
                        y: 0.4,
                        xref: 'x',
                        yref: 'y',
                        xanchor: 'center',
                        yanchor: 'center',
                        text: '1s',
                        font: {
                            family: "Fira Sans",
                            size: 26,
                            color: '#000000'
                        },
                        showarrow: false
                    },
                    {
                        x: 0.25,
                        y: 5,
                        xref: 'x',
                        yref: 'y',
                        xanchor: 'center',
                        yanchor: 'center',
                        text: '2p',
                        font: {
                            family: "Fira Sans",
                            size: 26,
                            color: '#000000'
                        },
                        showarrow: false
                    },
                    {
                        x: 0.25,
                        y: 9.5,
                        xref: 'x',
                        yref: 'y',
                        xanchor: 'center',
                        yanchor: 'center',
                        text: '3d',
                        font: {
                            family: "Fira Sans",
                            size: 26,
                            color: '#000000'
                        },
                        showarrow: false
                    },
                ],
            },
        };

       
        var lmin = 0,//minimum azimuthal quantum number
            lmax = 2,//maximum azimuthal quantum number
            selectedColor = "#FFA500",//color of selected line
            standardColor = "#000000";//color of all unselected lines
        
        function update_counter() {//updates the handle-counter environment when counter-button is pressed

            //defines limits and new values
            let newNumbers = {
                    l: v.l,
                    j: v.j,
                    mj: v.mj,
                    F: v.f,
                    mF: v.mf,
                };
                
            
            v.fMax= Math.abs(newNumbers.j+0.5);
            v.fMin= Math.abs(newNumbers.j-0.5);
            v.mjMin= -newNumbers.j;
            v.mjMax= newNumbers.j;

            v.mfMin=-newNumbers.F;
            v.mfMax=newNumbers.F;

            if (v.l != 0){
                v.jMax= v.l+ 1/2;
                v.jMin = v.l - 1/2;
            }
            else{
                v.jMax= 1/2;
                v.jMin= 1/2;
            }

            console.log("max");
            console.log(v.jMax);
            console.log("min");
            console.log(v.jMin);
            
        }

        function push_line(x0, x1, y0, y1, c) {//pushes a line to data
            if (c == standardColor) {//thickens line if highlighted 
                var width = 2;
            } else {
                width = 4;
            }
            data.push({mode: 'lines', line: {width: width, color: c}, x: [x0, x1], y: [y0, y1], showlegend: false});   // eslint-disable-line no-undef
        }

        function compare_obj(obj1, obj2, keys) {//keys is an array of keys to check. Assumes obj1, obj2 both have the keys
            var same = true;
            for (var i = 0; i < keys.length; i++) {
                if (obj1[keys[i]] !== obj2[keys[i]]) {
                    same = false;
                    break
                }
            }
            return same;
        }

        
        function get_data() {
            /*
            Adds all the necessary lines to data object
            
            NOTE: For Plotly.js to animate all the lines nicely, the same line
            needs to have the same trace number => A line will be animated towards
            the line in the new data object at the same index!
            IMPORTANT: Even if e.g. hyperfine is disabled, hyperfine lines need to
            be pushed in order for the animation to run smoothly...
            */
            
            data = [];
            var verPad = 4.5,                   //vertical padding between default lines
                //lambGap = -0.3,                 //gap for lamb shift
                //fSplit = 0.9,                   //gap for fine splitting
                //hfSplit = 0.6,                  //gap for hyperfine splitting
                lineColor,                      //value to store current line color 
                quantumNumbers = {              //quantum numbers selected
                    l: v.l, 
                    j: v.j,
                    mj: v.mj,
                    F: v.f,
                    mF: v.mf,
                },
                thisState = {};                 //object to store and compare quantum numbers

            for (var l=lmin; l<=lmax; l++) {
                var B = v.mag*(2*l*l+5*l+3)/(2*l*l+4*l+1.5);   //gap for zeeman splitting
                thisState.l = l;                                                //stores the lines current value of l in thisState

                //compares the quantum numbers of the selected state and the line. If true, the color is set to selectedColor
                if (compare_obj(quantumNumbers, thisState, ['l'])) {
                    lineColor = selectedColor 
                } else {
                    lineColor = standardColor
                }
                
                push_line(0.2, 0.9, l*verPad, l*verPad, lineColor);
                
                for (var j=Math.abs(l-0.5); j<=Math.abs(l+0.5); j++) {//iterates over j
                    thisState.j = j;


                    if (v.lamb == true && l==0) {
                        var lambShift = 0.1*13/4;       
                    } else {
                        lambShift = 0;
                    }


                    switch (true) {//sets line color based on conditions
                        case (v.fine == true && compare_obj(quantumNumbers, thisState, ['l'])):
                            if (quantumNumbers.j == j) {
                                lineColor = selectedColor;
                            } else {
                                lineColor = standardColor;
                            }
                            break
                        case (quantumNumbers.l == l):
                            lineColor = selectedColor;
                            break
                    }

                    if (v.fine == true && l != 0) {//shifts either up or down depending if j=l+0.5 or j=l-0.5
                        var fineShift = 0.5*(j*(j+1)-l*(l+1)-0.75);
                    } else {//if l=0 (s orbital), jmin=jmax, so level doesn't split
                        fineShift = 0;
                    }

                    push_line(1.1, 1.9, l*verPad+fineShift+lambShift, l*verPad+fineShift+lambShift, lineColor); //horizontal line
                    push_line(0.9, 1.1, l*verPad, l*verPad+fineShift+lambShift, lineColor);           //connects l and j line

                    for (var F=j-0.5; F<=j+0.5; F++) {//iterates over F
                        thisState.F = F;

                        if (v.hyperfine == true) {//shifts either up or down depending if F=j-0.5 or F=j+0.5
                            var hyperfineShift = 0.3*(F*(F+1)-j*(j+1)-0.75);
                        } else {//if hyperfine == false, have them be leveled with j lines
                            hyperfineShift = 0;
                        }

                        switch (true) {//sets line color based on conditions
                            case (v.fine == false && compare_obj(quantumNumbers, thisState, ['l'])):
                                lineColor = selectedColor;
                                break
                            case (v.fine == true && v.hyperfine == false && compare_obj(quantumNumbers, thisState, ['l', 'j'])):
                                lineColor = selectedColor;
                                break
                            case (v.fine == true && v.hyperfine == true && compare_obj(quantumNumbers, thisState, ['l', 'j'])):
                                if (quantumNumbers.F == F) {
                                    lineColor = selectedColor;
                                } else {
                                    lineColor = standardColor;
                                }
                                break
                            default:
                                lineColor = standardColor;
                                break
                        }

                        push_line(2.1, 2.9, l*verPad+fineShift+lambShift+hyperfineShift, l*verPad+fineShift+lambShift+hyperfineShift, lineColor);   //horizontal line
                        push_line(1.9, 2.1, l*verPad+fineShift+lambShift, l*verPad+fineShift+lambShift+hyperfineShift, lineColor);                  //connects j and F line

                        for (let mF=-F; mF<=F; mF++) {//iterates over mF
                            thisState.mF = mF;

                            if (v.zeeman == true && v.hyperfine == true) {//shifts in integer values of B
                                var zeemanShift = B*mF;
                            } else if (v.zeeman == true && v.fine == true) {
                                zeemanShift = B*j ; //so that all the lines overlay with the mj lines instead of standing out at mj = 0
                            } else {
                                zeemanShift = 0;
                            }
                            
                            switch (true) {//sets line color based on conditions
                                case (v.fine == false && compare_obj(quantumNumbers, thisState, ['l'])):
                                    lineColor = selectedColor;
                                    break
                                case (v.hyperfine == false && v.zeeman == true && compare_obj(quantumNumbers, thisState, ['l', 'j'])):
                                    if (quantumNumbers.mj == j) {//select lines that overlay the mj lines if that mj line is selected
                                        lineColor = selectedColor;
                                    } else {
                                        lineColor = standardColor;
                                    }
                                    break
                                case (v.fine == true && v.hyperfine == false && compare_obj(quantumNumbers, thisState, ['l', 'j'])):
                                    lineColor = selectedColor;
                                    break
                                case (v.hyperfine == true && v.zeeman == false && compare_obj(quantumNumbers, thisState, ['l', 'j' , 'F'])):
                                    lineColor = selectedColor;
                                    break
                                case (v.hyperfine == true && v.zeeman == true && compare_obj(quantumNumbers, thisState, ['l', 'j', 'F', 'mF'])):
                                    lineColor = selectedColor;
                                    break
                                default:
                                    lineColor = standardColor;
                                    break
                            }

                            push_line(3.1, 3.9, l*verPad+fineShift+lambShift+hyperfineShift+zeemanShift, l*verPad+fineShift+lambShift+hyperfineShift+zeemanShift, lineColor);   //horizontal line
                            push_line(2.9, 3.1, l*verPad+fineShift+lambShift+hyperfineShift, l*verPad+fineShift+lambShift+hyperfineShift+zeemanShift, lineColor);               //connects F and mF line
                        }
                    }

                    for (var mj=-j; mj<=j; mj++) {//iterates over mj
                        thisState.mj = mj;

                        if (v.zeeman == true && v.fine == true && v.hyperfine == false) {//shifts in integer values of B
                            zeemanShift = B*mj;
                        } else if (v.zeeman == true && v.hyperfine == true) {
                            zeemanShift = B*(j+0.5); //so that all the lines overlay with the mF lines instead of standing out at mF = 0
                        } else {
                            zeemanShift = 0;
                        }
                        
                        switch (true) {//sets line color based on conditions
                            case (v.fine == false && compare_obj(quantumNumbers, thisState, ['l'])):
                                lineColor = selectedColor;
                                break
                            case (v.hyperfine == false && v.zeeman == false && compare_obj(quantumNumbers, thisState, ['l','j'])):
                                lineColor = selectedColor;
                                break
                            case (v.hyperfine == false && v.zeeman == true && compare_obj(quantumNumbers, thisState, ['l', 'j', 'mj'])):
                                lineColor = selectedColor;
                                break
                            case (v.hyperfine == true && v.zeeman == true && compare_obj(quantumNumbers, thisState, ['l', 'j'])):
                                if (quantumNumbers.F == j+0.5 && quantumNumbers.mF == 0) {
                                    lineColor == selectedColor;
                                } else {
                                    lineColor == standardColor;
                                }
                                break
                            case (v.hyperfine == true && v.zeeman == false && compare_obj(quantumNumbers, thisState, ['l', 'j', 'F'])):
                                lineColor == selectedColor;
                                break
                            default:
                                lineColor = standardColor;
                                break
                        }

                        push_line(3.1, 3.9, l*verPad+fineShift+lambShift+hyperfineShift+zeemanShift, l*verPad+fineShift+lambShift+hyperfineShift+zeemanShift, lineColor);   //horizontal line
                        push_line(2.9, 3.1, l*verPad+fineShift+lambShift+hyperfineShift, l*verPad+fineShift+lambShift+hyperfineShift+zeemanShift, lineColor);               //connects j and mj line
                    }
                }
            }
    
            return data;
        }

        function initial() {//initiates visualisation
                        
            Plotly.purge("graph");
            Plotly.newPlot('graph', get_data(), plt.layout);
            
        }

        function update_graph() {//updates lines
            Plotly.animate("graph", {
                data: get_data(),
                layout: plt.layout
            }, {
                transition: {
                    duration: 500,
                    easing: 'cubic-in-out'
                },
            });
        }

        function animate(){
            requestAnimationFrame(animate);

            if (v.updateGraph==true){
                update_counter();
                update_graph();
                v.updateGraph=false;
            }
        } 

        initial();
        animate();

    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: left;
    padding-left:5vw;
    padding-right:25vw;
    margin-top: 30px;
}

.column {
  float: left;
  margin-top: 10px;
}

.left {
  width: 75%;
  padding-bottom:"10px";
}

.right {
  width: 25%;
  padding-bottom:"10px";
}


.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>