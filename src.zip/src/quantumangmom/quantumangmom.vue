<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="1">
            <template #hotspots>
                <iv-pane position="left" format="push" :width=28>
                    <iv-sidebar-content :showPagination="true">
                                                
                        <iv-sidebar-section title="Theory" icon="microscope" >
                            <p>
                                 In quantum mechanics, spin is an intrinsic angular momentum in particles. 
                                 Since angular momentum is quantised, we obtain two quantum numbers 
                                 <iv-equation-box :stylise="false" equation="s"/> and <iv-equation-box :stylise="false" equation="m_s"/>
                                 that defined our state.
                            </p>
                            <p>
                                Using the <iv-equation-box :stylise="false" equation="\mathbf{\hat{S}}^2"/> and 
                                <iv-equation-box :stylise="false" equation="\mathbf{\hat{S}}_z"/> operator we can 
                                measure the magnitude and <iv-equation-box :stylise="false" equation="z"/>-component of the spin vector with certainty.
                            </p>
                            <p>
                                However, <iv-equation-box :stylise="false" equation="S_x"/> and <iv-equation-box :stylise="false" equation="S_y"/> 
                                are not constant, so the classical vector with the appropriate length and 
                                <iv-equation-box :stylise="false" equation="z"/>-component spans all points forming a cone.
                            </p>
                            <p>
                                Note that due to the uncertainty in <iv-equation-box :stylise="false" equation="S_x"/> and 
                                <iv-equation-box :stylise="false" equation="S_y"/>, their expectation value is always zero, whilst since 
                                <iv-equation-box :stylise="false" equation="S_z"/> has no uncertainty, the expectation value of 
                                <iv-equation-box :stylise="false" equation="S_x ^2"/> and <iv-equation-box :stylise="false" equation="S_y ^2"/> is non zero.
                            </p>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Instructions" icon="question" theme="Lime" >
                            <p>
                                Open the controls tab and hit start to see the spin vector precessing. 
                                Change the quantum numbers to see how the cone changes.
                            </p>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Key equations" icon="calculator" theme="Purple">
                            <p>   
                                <iv-equation-box :stylise="true" equation="\mathbf{\hat{S}}^2\mathbf{\Psi}=\hbar^2 s(s+1)\mathbf{\Psi}"/>
                                <iv-equation-box :stylise="true" equation="\mathbf{\hat{S}}_z\mathbf{\Psi}=\hbar m_s\mathbf{\Psi}"/>
                            </p>

                        </iv-sidebar-section>

                        
                    </iv-sidebar-content>
                </iv-pane>

                <iv-toggle-hotspot :glass=true position="bottom" title="Controls" style=" z-index: 2;">      
                    <iv-toggle-advance id="toggle3" :togglesDisabled=disableList :modes=modeNames2 :initialModeIndex=3 @toggleswitched="msChange" position="centre"></iv-toggle-advance>
                    <label for="toggle3"> Secondary spin quantum number, m_s</label>    

                    <iv-toggle-advance id="toggle2" :modes=modeNames1 :initialModeIndex=0 @toggleswitched="sChange" position="centre"></iv-toggle-advance>
                    <label for="toggle2"> Spin quantum number, s </label>

                    <div style="width: 100px; float:left; margin:10px">
                        <label for="toggle1"> Stop/Start </label>
                        <iv-toggle-basic id="toggle1" @input="stopStartChange"> </iv-toggle-basic>
                    </div>   
                </iv-toggle-hotspot>

            </template>


            <div class="iv-welcome-message">
                
                <div class="row">
                    <div class="column left">                       
                        <h4 text-align:center>3D graph</h4>
                        <div id="graph3D" ></div>                    
                    </div>

                    <div class="column right">                       
                        <h4 text-align:center>2D graph</h4>
                        <div id="graph2D" ></div>                    
                    </div>
                </div> 
                
              
            </div>
        </iv-visualisation>
    </div>
</template>

<script>
import vue_config from '../../vue.config.js';
import Plotly from 'plotly.js/dist/plotly.min.js';
import {matrix,multiply} from 'mathjs';
export default {
    name:"quantumangmom",
    data(){
        return {
            pageName:"Quantum Angular Momentum",
            vue_config,
            stopStartChanged:false,
            stopStartChoice:true,
            graphUpdate: false,
            sChoice:1/2,
            msChoice:1/2,
            disableList: [true, false, true, false, true]
        }
    },
    props:{
        modeNames1:{default: ["1/2", "1"]},
        modeNames2:{default: ["-1","-1/2","0","1/2","1"]},
    },
    methods:{
        stopStartChange(e){  
            this.stopStartChoice=e;
            console.log("stopstartchoice");
            console.log(e);
            this.stopStartChanged=true;            
        },

        sChange(e){
            this.sChoice = (e +1) /2;
            this.graphUpdate = true;

            if(e == 0){
                this.disableList = [true, false, true, false, true];
               
            }
            if(e == 1){
                this.disableList = [false, true, false, true, false];
                
            }

            console.log("sChoice")
            console.log(this.sChoice)
        },

        msChange(e){                        
            this.msChoice = (e - 2)/2;
            this.graphUpdate = true;
            console.log("ms val")
            console.log(this.msChoice)
        },
    },

    mounted(){
        let v=this;

        function Vector(x, y, z) {
            this.x = x || 0;
            this.y = y || 0;
            this.z = z || 0;
        }

        Vector.prototype = {
            negative: function() {
                return new Vector(-this.x, -this.y, -this.z);
            },
            add: function(v) {
                if (v instanceof Vector) return new Vector(this.x + v.x, this.y + v.y, this.z + v.z);
                else return new Vector(this.x + v, this.y + v, this.z + v);
            },
            subtract: function(v) {
                if (v instanceof Vector) return new Vector(this.x - v.x, this.y - v.y, this.z - v.z);
                else return new Vector(this.x - v, this.y - v, this.z - v);
            },
            multiply: function(v) {
                if (v instanceof Vector) return new Vector(this.x * v.x, this.y * v.y, this.z * v.z);
                else return new Vector(this.x * v, this.y * v, this.z * v);
            },
            divide: function(v) {
                if (v instanceof Vector) return new Vector(this.x / v.x, this.y / v.y, this.z / v.z);
                else return new Vector(this.x / v, this.y / v, this.z / v);
            },
            equals: function(v) {
                return this.x == v.x && this.y == v.y && this.z == v.z;
            },
            dot: function(v) {
                return this.x * v.x + this.y * v.y + this.z * v.z;
            },
            cross: function(v) {
                return new Vector(
                this.y * v.z - this.z * v.y,
                this.z * v.x - this.x * v.z,
                this.x * v.y - this.y * v.x
                );
            },
            length: function() {
                return Math.sqrt(this.dot(this));
            },
            unit: function() {
                return this.divide(this.length());
            },
            min: function() {
                return Math.min(Math.min(this.x, this.y), this.z);
            },
            max: function() {
                return Math.max(Math.max(this.x, this.y), this.z);
            },
            toAngles: function() {
                return {
                theta: Math.atan2(this.z, this.x),
                phi: Math.asin(this.y / this.length())
                };
            },
            angleTo: function(a) {
                return Math.acos(this.dot(a) / (this.length() * a.length()));
            },
            toArray: function(n) {
                return [this.x, this.y, this.z].slice(0, n || 3);
            },
            clone: function() {
                return new Vector(this.x, this.y, this.z);
            },
            init: function(x, y, z) {
                this.x = x; this.y = y; this.z = z;
                return this;
            },
            //Custom functions, not in original file!
            vecToMatrix: function() {
                return matrix([[this.x], [this.y], [this.z]]);
            },
            //Multiplies vector object with a math.matrix object
            linearTransform: function(M) {
                return [].concat.apply([], multiply(M, this.vecToMatrix())["_data"]);
            },
            //Projects onto another vector
            project: function(v) {
                return v.unit().multiply(this.dot(v.unit()));
            },
        };

        Vector.negative = function(a, b) {
            b.x = -a.x; b.y = -a.y; b.z = -a.z;
            return b;
        };
        Vector.add = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x + b.x; c.y = a.y + b.y; c.z = a.z + b.z; }
            else { c.x = a.x + b; c.y = a.y + b; c.z = a.z + b; }
            return c;
        };
        Vector.subtract = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x - b.x; c.y = a.y - b.y; c.z = a.z - b.z; }
            else { c.x = a.x - b; c.y = a.y - b; c.z = a.z - b; }
            return c;
        };
        Vector.multiply = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x * b.x; c.y = a.y * b.y; c.z = a.z * b.z; }
            else { c.x = a.x * b; c.y = a.y * b; c.z = a.z * b; }
            return c;
        };
        Vector.divide = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x / b.x; c.y = a.y / b.y; c.z = a.z / b.z; }
            else { c.x = a.x / b; c.y = a.y / b; c.z = a.z / b; }
            return c;
        };
        Vector.cross = function(a, b, c) {
            c.x = a.y * b.z - a.z * b.y;
            c.y = a.z * b.x - a.x * b.z;
            c.z = a.x * b.y - a.y * b.x;
            return c;
        };
        Vector.unit = function(a, b) {
            var length = a.length();
            b.x = a.x / length;
            b.y = a.y / length;
            b.z = a.z / length;
            return b;
        };
        Vector.fromAngles = function(theta, phi) {
            return new Vector(Math.cos(theta) * Math.cos(phi), Math.sin(phi), Math.sin(theta) * Math.cos(phi));
        };
        Vector.randomDirection = function() {
            return Vector.fromAngles(Math.random() * Math.PI * 2, Math.asin(Math.random() * 2 - 1));
        };
        Vector.min = function(a, b) {
            return new Vector(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z));
        };
        Vector.max = function(a, b) {
            return new Vector(Math.max(a.x, b.x), Math.max(a.y, b.y), Math.max(a.z, b.z));
        };
        Vector.lerp = function(a, b, fraction) {
            return b.subtract(a).multiply(fraction).add(a);
        };
        Vector.fromArray = function(a) {
            return new Vector(a[0], a[1], a[2]);
        };
        Vector.angleBetween = function(a, b) {
            return a.angleTo(b);
        };


        const
        plt = {//layout of graph
            layout3D : {
                showscale: false,
                autosize: true,
                margin: {
                    l: 50, r: 20, b: 0, t: 50, pad: 0,
                },
                scene: {
                    aspectmode: "cube",
                    xaxis: {
                        autorange: false,
                        title: 'Lx',
                        titlefont: {
                            family: 'Fira Sans',
                            size: 18,
                            color: '#7f7f7f'
                        },
                        tickvals: [-1,-0.5,0,0.5,1],
                        ticktext: ["-\u0127","-\u0127/2",0,"\u0127/2","\u0127"],
                        range: [-1.5,1.5],
                    },
                    yaxis: {
                        autorange: false,
                        title: 'Ly',
                        titlefont: {
                            family: 'Fira Sans',
                            size:   18,
                            color: '#7f7f7f'
                        },
                        tickvals: [-1,-0.5,0,0.5,1],
                        ticktext: ["-\u0127","-\u0127/2",0,"\u0127/2","\u0127"],
                        range: [-1.5,1.5],
                    },
                    zaxis: {
                        autorange: false,
                        title: 'Lz',
                        titlefont: {
                            family: 'Fira Sans',
                            size: 18,
                            color: '#7f7f7f'
                        },
                        tickvals: [-1,-0.5,0,0.5,1],
                        ticktext: ["-\u0127","-\u0127/2",0,"\u0127/2","\u0127"],
                        range: [-1.5,1.5],
                    },
                    camera: {
                        eye: {
                            x: 1.8,
                            y: 1.2,
                            z: 1.2,
                        },
                    },
                },
                hovermode: false,
            },
            layout2D: {
                legend: {x: 0.2, y: -0.2, orientation: 'h'},
                autosize: true,
                margin: {
                    l: 50, r: 20, b: 0, t: 30, pad: 0,
                },
                xaxis: {
                    autorange: false,
                    title: 'L<sub>xy',
                    titlefont: {
                        family: "Fira Sans",
                        size: 22,
                        color: '#7f7f7f'
                    },
                    range: [-0.1,1.5],
                    tickvals: [0,0.5,1,1.5],
                    ticktext: [0,"\u0127/2","\u0127","3\u0127/2"],
                    tickfont: {
                    family: "Fira Sans",
                    size: 18,
                    color: 'black'
                    },
                },
                yaxis: {
                    autorange: false,
                    title: 'L<sub>z',
                    titlefont: {
                        family: "Fira Sans",
                        size: 22,
                        color: '#7f7f7f'
                    },
                    range: [-1.7,1.7],
                    tickvals: [-1.5,-1,-0.5,0,0.5,1,1.5],
                    ticktext: ["-3\u0127/2","-\u0127","-\u0127/2",0,"\u0127/2","\u0127","3\u0127/2"],
                    tickfont: {
                    family: "Fira Sans",
                    size: 18,
                    color: 'black'
                    },
                },
                hovermode: false,
            }
        };

        
        var t = 0;

        function get_rot_matrix(angle, vector) {//Returns rotation matrix about an arbitrary axis
            
            let [x,y,z] = vector.unit().toArray(),
                c = Math.cos(angle),
                s = Math.sin(angle),
                C = 1-c,
                Q = matrix([[x*x*C+c, x*y*C-z*s, x*z*C+y*s],[x*y*C+z*s, y*y*C+c, y*z*C-x*s],[x*z*C-y*s, y*z*C+x*s, z*z*C+c]]);
            
            
            return Q;
        }

        function make_sphere(V, r) {//makes a circle from a rotation vector V and radius r.
            // Dokumentation: https://math.stackexchange.com/questions/73237/parametric-equation-of-a-circle-in-3d-space
            let sphere = {x: [], y: [], z: []},     
                res = 20;                           //resolution of line
            
            V = V.unit();
            
            //determine a and b: two vectors perpendicular to the axis of rotation
            

            if (V.z == 0) {
                var a = new Vector(0,0,1);  //Necessary so we don't divide by zero
            } else {//set a1 = a2 = 1 and solve for a3...
                a = new Vector(1,1,-(V.x+V.y)/V.z).unit();
            }
            
            var b = a.cross(V);

            for (let theta=0; theta<=2*res; theta++) {//append points to object
                sphere.x.push(r*(a.x*Math.cos(theta*Math.PI/res)+b.x*Math.sin(theta*Math.PI/res)));
                sphere.y.push(r*(a.y*Math.cos(theta*Math.PI/res)+b.y*Math.sin(theta*Math.PI/res)));
                sphere.z.push(r*(a.z*Math.cos(theta*Math.PI/res)+b.z*Math.sin(theta*Math.PI/res)));
            }

            return sphere;
        }

        function draw3D_arrow(obj, pointsx, pointsy, pointsz, color) {//Returns an arrowhead based on an inputted line
            var x = 0.85*pointsx[1],                    //xyz are points of arrow
                y = 0.85*pointsy[1],
                z = 0.85*pointsz[1],
                u = 0.2*(pointsx[1] - pointsx[0]),      //uvw is direction of arrow
                v = 0.2*(pointsy[1] - pointsy[0]),
                w = 0.2*(pointsz[1] - pointsz[0]);
            obj.push({
                type: "cone",
                colorscale: [[0, color],[1,color]],
                x: [x],
                y: [y],
                z: [z],
                u: [u],
                v: [v],
                w: [w],
                sizemode: "absolute",
                sizeref: 0.3*Math.sqrt(Vector.fromArray([x,y,z]).length()),
                showscale: false,
            });
        }

        function get3D_data() {
            let data,
                s = v.sChoice , 
                ms = v.msChoice,
                freqS = 1/20,                   //frequency of rotation
                lenS = Math.sqrt(s*(s+1)),      //length of spin vector
                theta = Math.acos(ms/lenS),     //angle between vector and z-axis
                vectorS = new Vector(lenS*Math.sin(theta)*Math.cos(t*freqS), lenS*Math.sin(theta)*Math.sin(t*freqS), ms),
                S_cone = {x: [], y: [], z: []},
                Z = new Vector(0,0,1),
                [Sx,Sy,Sz] = vectorS.toArray(3);
         

            for (let i=0; i<50; i++) {//append points of cone
                S_cone.x.push(0); S_cone.y.push(0); S_cone.z.push(0);

               

                S_cone.x.push(vectorS.linearTransform(get_rot_matrix(i,Z))[0]);
                S_cone.y.push(vectorS.linearTransform(get_rot_matrix(i,Z))[1]);
                S_cone.z.push(vectorS.linearTransform(get_rot_matrix(i,Z))[2]);
                
            }

            //make the three circles that form the sphere
            let S_sphere1 = make_sphere(new Vector(Math.cos(-t/10),Math.sin(-t/10),0), lenS),
                S_sphere2 = make_sphere(new Vector(Math.sin(t/10),Math.cos(t/10),0), lenS),
                S_sphere3 = make_sphere(new Vector(0,0,1), lenS);


           

            data = [        
                {//S vector
                    name: 'Spin',
                    type: 'scatter3d',
                    mode: 'lines',
                    line: {width: 10, dash: 'solid', color: '#50C878'},
                    legendgroup: 's',
                    x: [0, Sx],
                    y: [0, Sy],
                    z: [0, Sz],
                    showlegend: false,
                },
                {//S vector cone
                    type: 'mesh3d',
                    color: '#50C878',
                    opacity: 0.4,
                    x: S_cone.x,
                    y: S_cone.y,
                    z: S_cone.z,
                },
                {//first S vector circle
                    type: 'scatter3d',
                    mode: 'lines',
                    opacity: 1,
                    line: {
                        width: 4,
                        color: '#000000',
                    },
                    x: S_sphere1.x,
                    y: S_sphere1.y,
                    z: S_sphere1.z,
                    showlegend: false,
                },
                {//second S vector circle
                    type: 'scatter3d',
                    mode: 'lines',
                    opacity: 1,
                    line: {
                        width: 4,
                        color: '#000000',
                    },
                    x: S_sphere2.x,
                    y: S_sphere2.y,
                    z: S_sphere2.z,
                    showlegend: false,
                },
                {//equator S vector circle
                    type: 'scatter3d',
                    mode: 'lines',
                    opacity: 1,
                    line: {
                        width: 4,
                        color: '#000000',
                    },
                    x: S_sphere3.x,
                    y: S_sphere3.y,
                    z: S_sphere3.z,
                    showlegend: false,
                },
                {//Lz component of S vector
                    type: 'scatter3d',
                    mode: 'lines',
                    line: {
                        width: 10,
                        dash: 'dash',
                        color: '#50C878',
                    },
                    x: [0, Sx],
                    y: [0, Sy],
                    z: [Sz, Sz],
                    showlegend: false,
                },
            ];
            draw3D_arrow(data, [0, Sx], [0, Sy], [0, Sz], '#50C878');

            return data;
        }
        
        function draw_arrowtips(obj, x, y, angle, length_ratio, color) {
            /* rotates the vector -angle and +angle to make the two tips,
            scales down to length_ratio and pushes to obj */
            
            let vec1 = new Vector(Math.cos(angle),Math.sin(angle),0).multiply(x).add(new Vector(-Math.sin(angle),Math.cos(angle),0).multiply(y)).multiply(length_ratio),
                vec2 = new Vector(Math.cos(-angle),Math.sin(-angle),0).multiply(x).add(new Vector(-Math.sin(-angle),Math.cos(-angle),0).multiply(y)).multiply(length_ratio);
            
            obj.push({x: [x, x+vec1.x], y: [y, y+vec1.y], mode: "lines", line: {width: 3, color: color}, showlegend: false});
            obj.push({x: [x, x+vec2.x], y: [y, y+vec2.y], mode: "lines", line: {width: 3, color: color}, showlegend: false});        
        }

        function make_circle(r) {//draws the 2D circle
            let circle = {x: [], y: []},
                res = 100;

            for (let phi=0; phi<=res; phi++) {//append points
                circle.x.push(r*Math.sin(phi*Math.PI/res));
                circle.y.push(r*Math.cos(phi*Math.PI/res));
            }

            return circle
        }
        
        function get2D_data() {
            let data,
                s = v.sChoice,
                ms = v.msChoice ,
                xs = Math.sqrt(s*(s+1)-Math.pow(ms, 2)),            //the x position of the vector
                circle = make_circle(Math.sqrt(s*(s+1)));
            
            data = [
                {//S vector
                    name: "Spin",
                    mode: "lines",
                    line: {
                        width: 4,
                        color: "50C878"
                    },
                    x: [0, xs],
                    y: [0, ms],
                    showlegend: false
                },
                {//Lz component of S vector
                    mode: "lines",
                    line: {
                        width: 4,
                        dash: "dash",
                        color: "50C878"
                    },
                    x: [0, xs],
                    y: [ms, ms],
                    showlegend: false
                },
                {//circle with radius the length of S
                    type: "scatter",
                    mode: "lines",
                    line: {
                        width: 4,
                        color: "000000"
                    },
                    x: circle.x,
                    y: circle.y,
                    showlegend: false
                },
            ];
            draw_arrowtips(data, xs, ms, 7*Math.PI/8, 0.2, '50C878');
            
            return data;
        }

        function initial() {//Plots the initial data and shifts from loading to container       
                      
            Plotly.purge("graph3D");
            Plotly.newPlot("graph3D", get3D_data(), plt.layout3D);

            Plotly.purge("graph2D");
            Plotly.newPlot("graph2D", get2D_data(), plt.layout2D);
            
            update2D_graph();
            update3D_graph();

            
        }

        function update3D_graph() {//Updates the data
            Plotly.animate('graph3D', {
                data: get3D_data()
            }, {
                fromcurrent: true,
                frame: {
                    duration: 0, 
                    redraw: true,
                },
                transition: {
                    duration: 0
                },
                mode: 'next',
            });

            if (v.stopStartChoice == false) {
                t++;

            }
        }

        function update2D_graph() {
            Plotly.animate('graph2D', {
                data: get2D_data(), 
                layout: plt.layout2D,
            }, {
                transition: {
                    duration: 250,
                    easing: 'cubic-in-out'
                },
                mode: 'next',
            });
        }
        
        initial();
    

        function animate(){
            requestAnimationFrame(animate);

            if (v.stopStartChoice===false){
                update3D_graph();
                
            }
            

            if (v.graphUpdate==true){
            
                update3D_graph();
                update2D_graph();
            }
         
        }
        animate();
    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
}

.column {
  float: left;
}

.left {
  width: 35vw;
}

.right {
  width: 35vw;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>