<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="3">
            <template #hotspots>
                <iv-pane position="left" format="push" :width=28>
                    <iv-sidebar-content :showPagination="true">
                        
                        <iv-sidebar-section title="Theory" icon="microscope" >
                            <p>
                                The electron's spin gives rise to a magnetic moment 
                                <iv-equation-box :stylise="true" equation="\mathbf{\mu}_s=-\mu_B\mathbf{\hat{s}}"/>. 
                                Since there is no external torque on the atom, the <b>total angular momentum must be constant</b>. 
                                However, the spin and orbital angular momenta, <iv-equation-box :stylise="false" equation="\mathbf{S}"/> 
                                and <iv-equation-box :stylise="false" equation="\mathbf{L}"/>, both precess around 
                                <iv-equation-box :stylise="false" equation="\mathbf{J}"/> due to the torque coming from the 
                                interaction <iv-equation-box :stylise="true" equation="-\mathbf{\mu}_s\cdot\mathbf{B}"/>.

                            </p>
                            <p>
                                For a two-electron system, either <iv-equation-box :stylise="false" equation="\mathbf{s}_1,\mathbf{s}_2"/>
                                couple to form a total spin vector <iv-equation-box :stylise="false" equation="\mathbf{S}"/>
                                (likewise with <iv-equation-box :stylise="false" equation="\mathbf{l}_1,\mathbf{l}_2 ,"/>) or
                                <iv-equation-box :stylise="false" equation="\mathbf{s}_1,\mathbf{l}_1"/> and 
                                <iv-equation-box :stylise="false" equation="\mathbf{s}_2,\mathbf{l}_2"/> couple to make total 
                                angular momentum vectors <iv-equation-box :stylise="false" equation="\mathbf{j}_1,\mathbf{j}_2 ."/>

                            </p>
                            

                        </iv-sidebar-section>

                        <iv-sidebar-section title="Instructions" icon="question" theme="Lime" >
                            <p>
                                Change the quantum numbers by opening the tab at the button, to see how <iv-equation-box :stylise="false" equation="\mathbf{s}"/>
                                and <iv-equation-box :stylise="false" equation="\mathbf{l}"/> affect <iv-equation-box :stylise="false" equation="\mathbf{j}"/>. 
                                Change <iv-equation-box :stylise="false" equation="m_j"/> to see how the the orientation changes on the diagram.
                            </p>
                            <p>
                                What effect do you think the Zeeman effect would have on the vectors? Note that the cones map out the 
                                vectors precession. 
                            </p>
                        </iv-sidebar-section>
                        
                    
                        <iv-sidebar-section title="Derivation" icon="calculator" theme="Purple" >
                            <p>
                                In a single-electron atom, due to the spin of the electron <iv-equation-box :stylise="false" equation="\mathbf{s}"/>, 
                                it also has a magnetic moment <iv-equation-box :stylise="true" equation="\mathbf{\mu}_s=-\frac{ge}{2m}\mathbf{s}"/>,
                                where <iv-equation-box :stylise="false" equation="g\approx 2"/> is the <i>gyromagnetic ratio</i>. Now the electron is 
                                moving in the electric field of the nucleus, so it experiences a magnetic field in its moving frame 
                                which interacts with <iv-equation-box :stylise="false" equation="\mathbf{\mu}_s"/>. Classically, the magnetic 
                                field seen by the electron is 
                                <iv-equation-box :stylise="true" equation="\mathbf{B}=-\frac{1}{c^2}\mathbf{v}\times\mathbf{E}=-\frac{1}{ec^2}\mathbf{v}\times\nabla V(r)"/>,
                                where <iv-equation-box :stylise="false" equation="\mathbf{v}"/> is its velocity vector, 
                                <iv-equation-box :stylise="false" equation="\mathbf{E}"/> is the electric field, and 
                                <iv-equation-box :stylise="true" equation="V(r)=-\frac{Ze^2}{4\pi\varepsilon_0r}"/>. This magnetic 
                                field <b>interacts with the spin magnetic moment</b>: the <i>spin-orbit interaction</i>.
                            </p>
                            <p>
                                Since there is no external torque on the atom itself, a coupling between the orbital angular momentum 
                                <iv-equation-box :stylise="false" equation="\mathbf{l}"/> and spin <iv-equation-box :stylise="false" equation="\mathbf{s}"/> 
                                must result in a total angular momentum <iv-equation-box :stylise="false" equation="\mathbf{j}"/>, where 
                                <iv-equation-box :stylise="false" equation="|\mathbf{j}|"/> and <iv-equation-box :stylise="false" equation="\mathbf{j}_z"/> 
                                are constant. However, if placed in the magnetic field, <iv-equation-box :stylise="false" equation="\mathbf{j}"/>
                                therefore precesses around the <iv-equation-box :stylise="false" equation="z"/>-axis due to the torque
                                <iv-equation-box :stylise="true" equation="\mathbf{\tau}=\mathbf{\mu}\times\mathbf{B}=-\frac{e}{m}\mathbf{j}\times\mathbf{B}"/>.
                                Likewise, <iv-equation-box :stylise="false" equation="\mathbf{s}"/> and <iv-equation-box :stylise="false" equation="\mathbf{l}"/>
                                precess around <iv-equation-box :stylise="false" equation="\mathbf{j}"/>. This also implies that 
                                <iv-equation-box :stylise="false" equation="\mathbf{l}"/> and <iv-equation-box :stylise="false" equation="\mathbf{l}_z"/>
                                are no longer constant, so <iv-equation-box :stylise="false" equation="m_s"/> and <iv-equation-box :stylise="false" equation="m_l"/>
                                are no longer suitable quantum numbers. Instead, we introduce the total angular momentum quantum number 
                                <iv-equation-box :stylise="true" equation="j=s+l"/> and the corresponding secondary number 
                                <iv-equation-box :stylise="false" equation="m_j"/> that takes values 
                                <iv-equation-box :stylise="false" equation="-j,\dots,j"/> in integer steps.
                            </p>
                            
                            <figure>
                                <img src = "assets/vectors.png" width=100% >
                                <figcaption>
                                    <p align="center">
                                    LS-coupling diagram
                                    </p>
                                </figcaption>    
                            </figure>
                            
                            <p>
                                 In <b>two-electron systems</b> the total angular momentum <iv-equation-box :stylise="false" equation="\mathbf{J}"/>
                                 also precesses around the <iv-equation-box :stylise="false" equation="z"/>-axis, but the 
                                 individual orbital and spin angular momenta of the electrons, 
                                 <iv-equation-box :stylise="false" equation="\mathbf{s}_1,\mathbf{l}_1,\mathbf{s}_2,\mathbf{l}_2"/>
                                 can couple in different ways.
                            </p>
                            <p>
                                Either the vectors pair up to make a <i>total</i> orbital and spin angular momentum 
                                <iv-equation-box :stylise="true" equation="\mathbf{S}=\mathbf{s}_1+\mathbf{s}_2"/> and 
                                <iv-equation-box :stylise="true" equation="\mathbf{L}=\mathbf{l}_1+\mathbf{l}_2"/>, which is 
                                called <b>LS-coupling</b>. These then behave much like single-electron systems, where 
                                <iv-equation-box :stylise="false" equation="\mathbf{L}"/> and <iv-equation-box :stylise="false" equation="\mathbf{S}"/>
                                precess around <iv-equation-box :stylise="false" equation="\mathbf{J}"/>. The second possibility is 
                                coupling within each electron, giving two total angular momenta <iv-equation-box :stylise="true" equation="\mathbf{j}_1=\mathbf{l}_1+\mathbf{s}_1"/>
                                and <iv-equation-box :stylise="true" equation="\mathbf{j}_2=\mathbf{l}_2+\mathbf{s}_2"/>. This is called <b>jj-coupling</b> 
                                and likewise, they precess around the total angular momentum of the atom <iv-equation-box :stylise="false" equation="\mathbf{J}"/>.
                            </p>
                            <p>
                                <iv-equation-box :stylise="true" equation="\begin{matrix}
                                \mathbf{s}_1 & + & \mathbf{l}_1 & \Rightarrow & \mathbf{j}_1 \\
                                + & & + & & + \\ 
                                \mathbf{s}_2 & + & \mathbf{l}_2 & \Rightarrow & \mathbf{j}_2 \\ 
                                \Downarrow & & \Downarrow & & \Downarrow \\ 
                                \mathbf{S} & + & \mathbf{L} & \Rightarrow & \mathbf{J}
                                \end{matrix}"/>
                            </p>

                        </iv-sidebar-section>
                                            
                    </iv-sidebar-content>
                </iv-pane>

                <iv-fixed-hotspot :noWastedSpace="true" position="topright" style=" z-index: 2;" >
        
                    <iv-toggle-advance :modes=modeNames1 @toggleswitched="electronChange" position="centre"></iv-toggle-advance>

                    <div id="oneElectron" v-show="electrons == 1">
                        <label for="coneToggle"> Cones Off/On </label>
                        <iv-toggle-basic id="coneToggle" :value="true" @input="coneChange"> </iv-toggle-basic>
                    </div>

                    <!-- <div id="twoElectrons" v-show="electrons == 2">
                        <label for="jjToggle"> jj-coupling Off/On </label>
                        <iv-toggle-basic id="jjToggle" :value="true" @input="jjChange"> </iv-toggle-basic>
                    </div> -->

                    <div>
                        <label for="playToggle"> Zeeman effect Off/On </label>
                        <iv-toggle-basic id="playToggle" @input="stopStartChange"> </iv-toggle-basic>
                    </div>
                </iv-fixed-hotspot>


                <iv-toggle-hotspot :glass=true position="bottom" title="Quantum numbers" style=" z-index: 2;" >
                    <div>           
                        <div id="oneElectron" v-show="electrons == 1">
                            
                            <label for="toggle2"> Spin quantum number, s </label>
                            <iv-toggle-advance id="toggle2" :modes=sModeNames :width=toggleWidth :initialModeIndex=0 @toggleswitched="sChange" position="centre"></iv-toggle-advance>
                            
                            <label for="toggle3"> Azimuthal quantum number, l </label>
                            <iv-toggle-advance id="toggle3" :modes=lModeNames :width=toggleWidth :initialModeIndex=1 @toggleswitched="lChange" position="centre"></iv-toggle-advance>
                        </div>

                        <!-- <div id="twoElectrons" v-show="electrons == 2">
                            <div class="row">
                                <div class="column">
                                    <label for="toggle4"> Spin quantum number, s_1 </label>
                                    <iv-toggle-advance id="toggle4" :width=toggleWidth :modes=sModeNames :initialModeIndex=1 @toggleswitched="s1Change" position="centre"></iv-toggle-advance>
                                    
                                    <label for="toggle5"> Azimuthal quantum number, l_1 </label>
                                    <iv-toggle-advance id="toggle5" :width=toggleWidth :modes=lModeNames :initialModeIndex=0 @toggleswitched="l1Change" position="centre"></iv-toggle-advance>
                                </div>
                                <div class="column">
                                    <label for="toggle6"> Spin quantum number, s_2 </label>
                                    <iv-toggle-advance id="toggle6" :width=toggleWidth :modes=sModeNames :initialModeIndex=0 @toggleswitched="s2Change" position="centre"></iv-toggle-advance>
                                    
                                    <label for="toggle7"> Azimuthal quantum number, l_2 </label>
                                    <iv-toggle-advance id="toggle7" :width=toggleWidth :modes=lModeNames :initialModeIndex=1 @toggleswitched="l2Change" position="centre"></iv-toggle-advance>
                
                                </div>
                            </div> 
                        </div> -->

                        <p>
                        Total angular momentum quantum number: {{j}}
                        </p>

                        <div v-if="jWhole == true">
                            <label for="mjToggle1"> Secondary total angular momentum quantum number, m_j </label>
                            <iv-toggle-advance id="mjToggle1" :width=toggleWidth :togglesDisabled=disableList1 :modes=mjModeNames1 :initialModeIndex=0 @toggleswitched="mjChange" position="centre"></iv-toggle-advance>
                        </div>

                        <div v-if="jWhole == false">
                            <label for="mjToggle2"> Secondary total angular momentum quantum number, m_j </label>
                            <iv-toggle-advance id="mjToggle2" :width=toggleWidth :togglesDisabled=disableList2 :modes=mjModeNames2 :initialModeIndex=4 @toggleswitched="mjChange" position="centre"></iv-toggle-advance>
                        </div>

                    </div>

                
                        
                </iv-toggle-hotspot>


            </template>
            
            <div class="iv-welcome-message">
                <div id = "graph"></div>
                
            </div>
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js';
import Plotly from 'plotly.js/dist/plotly.min.js';
import {matrix,multiply} from 'mathjs';
export default {
    name:"spincoupling",
    data(){
        return {
            pageName:"Spin Orbit Coupling",
            vue_config,
            electrons:1,
            cones:true,
            jjChoice:true,
            stopStartChanged:false,
            playAnimation:false,
            lChoice:1,
            l1Choice:0,
            l2Choice:1,
            sChoice:1/2,
            s1Choice:1,
            s2Choice:1/2,
            mjChoice:1/2,
            electronChanged:false,
            j:1.5,
            jWhole:false,
            disableList2: [true, true, true, false, false, true, true, true],
            disableList1: [true, true, true, true, true, true, true, true, true],
            coupling: "LS",
            couplingChanged:false,
        }
    },
    props:{
        modeNames1:{default:["One Electron"] },
        // modeNames1:{default:["One Electron","Two Electrons"] },
        sModeNames:{default: ["1/2", "1"]},
        lModeNames:{default: ["0","1","2","3"]},
        mjModeNames1:{default: ["-4","-3","-2","-1","0","1","2","3","4"]},
        mjModeNames2:{default: ["-7/2","-5/2","-3/2","-1/2","1/2","3/2","5/2","7/2"]},
        toggleWidth:{default: '45px'}

    },

    methods:{
        electronChange(e){
            this.electrons=e+1;
            if(this.electrons==1){
                this.j=this.sChoice+this.lChoice;
                this.coupling="LS";
            }
            else{
                this.j=this.s1Choice+this.s2Choice+this.l1Choice+this.l2Choice;
                this.coupling="jj";

            }
            this.mjDisable();
            this.electronChanged=true;
        },

        jjChange(e){
            console.log("e");
            console.log(e);
            if (e==false){
                this.coupling="jj";
            }
            else {
                this.coupling="LS";
            }
            
            this.graphUpdate = true;
            
        },

        coneChange(e){
            this.cones= !e;
            this.graphUpdate = true;
            
        },

        stopStartChange(e){  
            console.log(e);
            this.playAnimation= !e;
            this.stopStartChanged=true;            
        },

        sChange(e){
            this.sChoice = (e +1) /2;
            this.j=this.sChoice+this.lChoice;
            
            if ((this.j) %1 == 0){
                this.jWhole = true
            }
            else {
                this.jWhole = false
            }

            this.mjDisable();
            this.graphUpdate = true;
        
        },

        mjDisable(){
            if (this.jWhole==true){
                let startIndex= Math.abs(this.j-4);
                let endIndex= startIndex + 2*this.j;
                let arr = [];

                if (endIndex>8){
                    this.disableList1=[false,false,false,false,false,false,false,false]
                }
                else{
                    for(let i = 0; i < 9; i++){
                        if (i>= startIndex && i<=endIndex){
                            arr.push(false);
                        }
                        else {
                            arr.push(true);
                        }
                    }
                    this.disableList1=arr;
                }

            }
            else{
                let startIndex= Math.abs(this.j-3.5);
                let endIndex= startIndex + 2*this.j;
                let arr = [];

                if (endIndex>7){
                    this.disableList1=[false,false,false,false,false,false,false,false,false]
                }
                else{
                    for(let i = 0; i < 8; i++){
                        if (i>= startIndex && i<=endIndex){
                            arr.push(false);
                        }
                        else {
                            arr.push(true);
                        }
                    }
                    this.disableList2=arr;
                }
            }

        },

        s1Change(e){
            this.s1Choice = (e +1) /2;
            this.j=this.s1Choice+this.s2Choice+this.l1Choice+this.l2Choice

            if ((this.j) %1 == 0){
                this.jWhole = true
            }
            else {
                this.jWhole = false
            }

            this.mjDisable();
            this.graphUpdate = true;
        },

        s2Change(e){
            this.s2Choice = (e +1) /2;
            this.j=this.s1Choice+this.s2Choice+this.l1Choice+this.l2Choice

            if ((this.j) %1 == 0){
                this.jWhole = true
            }
            else {
                this.jWhole = false
            }

            this.mjDisable();
            this.graphUpdate = true;

        },

        lChange(e){
            this.lChoice = e;
            this.j=this.sChoice+this.lChoice;
            
            if ((this.j) %1 == 0){
                this.jWhole = true
            }
            else {
                this.jWhole = false
            }

            this.mjDisable();
            this.graphUpdate = true;
        },

        l1Change(e){
            this.l1Choice = e;
            this.j=this.s1Choice+this.s2Choice+this.l1Choice+this.l2Choice

            if ((this.j) %1 == 0){
                this.jWhole = true
            }
            else {
                this.jWhole = false
            }

            this.mjDisable();
            this.graphUpdate = true;
        },

        l2Change(e){
            this.l2Choice = e;
            this.j=this.s1Choice+this.s2Choice+this.l1Choice+this.l2Choice

            if ((this.j) %1 == 0){
                this.jWhole = true
            }
            else {
                this.jWhole = false
            }

            this.mjDisable();
            this.graphUpdate = true;
        },

        mjChange(e){
            if (this.jWhole==true){
                this.mjChoice = e -4;
            }
            else {
                this.mjChoice = e-(7/2);
            }
            
            console.log("mj");
            console.log(this.mjChoice);
            this.graphUpdate = true;
        },
    },

    mounted(){
        let v=this;

        function Vector(x, y, z) {
            this.x = x || 0;
            this.y = y || 0;
            this.z = z || 0;
        }

        Vector.prototype = {
            negative: function() {
                return new Vector(-this.x, -this.y, -this.z);
            },
            add: function(v) {
                if (v instanceof Vector) return new Vector(this.x + v.x, this.y + v.y, this.z + v.z);
                else return new Vector(this.x + v, this.y + v, this.z + v);
            },
            subtract: function(v) {
                if (v instanceof Vector) return new Vector(this.x - v.x, this.y - v.y, this.z - v.z);
                else return new Vector(this.x - v, this.y - v, this.z - v);
            },
            multiply: function(v) {
                if (v instanceof Vector) return new Vector(this.x * v.x, this.y * v.y, this.z * v.z);
                else return new Vector(this.x * v, this.y * v, this.z * v);
            },
            divide: function(v) {
                if (v instanceof Vector) return new Vector(this.x / v.x, this.y / v.y, this.z / v.z);
                else return new Vector(this.x / v, this.y / v, this.z / v);
            },
            equals: function(v) {
                return this.x == v.x && this.y == v.y && this.z == v.z;
            },
            dot: function(v) {
                return this.x * v.x + this.y * v.y + this.z * v.z;
            },
            cross: function(v) {
                return new Vector(
                this.y * v.z - this.z * v.y,
                this.z * v.x - this.x * v.z,
                this.x * v.y - this.y * v.x
                );
            },
            length: function() {
                return Math.sqrt(this.dot(this));
            },
            unit: function() {
                return this.divide(this.length());
            },
            min: function() {
                return Math.min(Math.min(this.x, this.y), this.z);
            },
            max: function() {
                return Math.max(Math.max(this.x, this.y), this.z);
            },
            toAngles: function() {
                return {
                theta: Math.atan2(this.z, this.x),
                phi: Math.asin(this.y / this.length())
                };
            },
            angleTo: function(a) {
                return Math.acos(this.dot(a) / (this.length() * a.length()));
            },
            toArray: function(n) {
                return [this.x, this.y, this.z].slice(0, n || 3);
            },
            clone: function() {
                return new Vector(this.x, this.y, this.z);
            },
            init: function(x, y, z) {
                this.x = x; this.y = y; this.z = z;
                return this;
            },
            //Custom functions, not in original file!
            vecToMatrix: function() {
                return matrix([[this.x], [this.y], [this.z]]);
            },
            //Multiplies vector object with a math.matrix object
            linearTransform: function(M) {
                return [].concat.apply([], multiply(M, this.vecToMatrix())["_data"]);
            },
            //Projects onto another vector
            project: function(v) {
                return v.unit().multiply(this.dot(v.unit()));
            },
            };

            Vector.negative = function(a, b) {
            b.x = -a.x; b.y = -a.y; b.z = -a.z;
            return b;
            };
            Vector.add = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x + b.x; c.y = a.y + b.y; c.z = a.z + b.z; }
            else { c.x = a.x + b; c.y = a.y + b; c.z = a.z + b; }
            return c;
            };
            Vector.subtract = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x - b.x; c.y = a.y - b.y; c.z = a.z - b.z; }
            else { c.x = a.x - b; c.y = a.y - b; c.z = a.z - b; }
            return c;
            };
            Vector.multiply = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x * b.x; c.y = a.y * b.y; c.z = a.z * b.z; }
            else { c.x = a.x * b; c.y = a.y * b; c.z = a.z * b; }
            return c;
            };
            Vector.divide = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x / b.x; c.y = a.y / b.y; c.z = a.z / b.z; }
            else { c.x = a.x / b; c.y = a.y / b; c.z = a.z / b; }
            return c;
            };
            Vector.cross = function(a, b, c) {
            c.x = a.y * b.z - a.z * b.y;
            c.y = a.z * b.x - a.x * b.z;
            c.z = a.x * b.y - a.y * b.x;
            return c;
            };
            Vector.unit = function(a, b) {
            var length = a.length();
            b.x = a.x / length;
            b.y = a.y / length;
            b.z = a.z / length;
            return b;
            };
            Vector.fromAngles = function(theta, phi) {
            return new Vector(Math.cos(theta) * Math.cos(phi), Math.sin(phi), Math.sin(theta) * Math.cos(phi));
            };
            Vector.randomDirection = function() {
            return Vector.fromAngles(Math.random() * Math.PI * 2, Math.asin(Math.random() * 2 - 1));
            };
            Vector.min = function(a, b) {
            return new Vector(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z));
            };
            Vector.max = function(a, b) {
            return new Vector(Math.max(a.x, b.x), Math.max(a.y, b.y), Math.max(a.z, b.z));
            };
            Vector.lerp = function(a, b, fraction) {
            return b.subtract(a).multiply(fraction).add(a);
            };
            Vector.fromArray = function(a) {
            return new Vector(a[0], a[1], a[2]);
            };
            Vector.angleBetween = function(a, b) {
            return a.angleTo(b);
            };

        const
        plt = {//layout of graph
            layout : {
                legend: {x: 0, y: 0, orientation: 'h'},
                showscale: false,
                margin: {
                    l: 1, r: 0, b: 0, t: 1, pad: 5
                },
                scene: {
                    aspectmode: "cube",
                    xaxis: {
                        title: 'Lx',
                        titlefont: {
                            family: 'Fira Sans',
                            size: 18,
                            color: '#7f7f7f'
                        },
                        tickvals: [-4,-3,-2,-1,0,1,2,3,4],
                        ticktext: ["-4\u0127","-3\u0127","-2\u0127","-\u0127",0,"\u0127","2\u0127","3\u0127","4\u0127"],
                    },
                    yaxis: {
                        title: 'Ly',
                        titlefont: {
                            family: 'Fira Sans',
                            size:   18,
                            color: '#7f7f7f'
                        },
                        tickvals: [-4,-3,-2,-1,0,1,2,3,4],
                        ticktext: ["-4\u0127","-3\u0127","-2\u0127","-\u0127",0,"\u0127","2\u0127","3\u0127","4\u0127"],
                    },
                    zaxis: {
                        title: 'Lz',
                        titlefont: {
                            family: 'Fira Sans',
                            size: 18,
                            color: '#7f7f7f'
                        },
                        tickvals: [-4,-3,-2,-1,0,1,2,3,4],
                        ticktext: ["-4\u0127","-3\u0127","-2\u0127","-\u0127",0,"\u0127","2\u0127","3\u0127","4\u0127"],
                    },
                    camera: {
                        eye: {
                            x: 1.2,
                            y: 1.2,
                            z: 1.1,
                        },
                    },
                },
                hovermode: false,
            }
        };


        var t = 0;

        function change_electrons() {//changes the number of electrons
            //See README file regarding Plotly.deleteTraces and addTraces
            //It is necessary for animations when switching between one and two electrons

            // let s1Text = MathJax.Hub.getAllJax("s1Text")[0],    //loads the MathJax environment to alter
            //     l1Text = MathJax.Hub.getAllJax("l1Text")[0];    //LaTeX formatted text in HTML

            if (v.electrons == 2) {//change number of electrons to 2
                
                //Add traces and force hidden cones
                Plotly.deleteTraces("graph", [-1,-2,-3,-4,-5])
                Plotly.addTraces("graph", [{},{},{},{},{},{},{},{},{},{}]);
                v.cones = true;
                display_cones();
                
            } else {//change number of electrons to 1
                
                //Remove the traces of the s1,s2,l1,l2 vectors and enable the cone button
                Plotly.deleteTraces("graph", [-1,-2,-3,-4,-5,-6,-7,-8,-9,-10]);
                Plotly.addTraces("graph", [{},{},{},{},{}]);
                // document.getElementById("coneButton").disabled = false;

                v.coupling = "jj";
                change_coupling(); //this makes sure that coupling = "LS" if set to 1 electron
            }

        }

        function change_coupling() {//Switch between LS coupling and jj coupling
            if (v.coupling == "LS") {//change coupling type to jj
                v.coupling = "jj";
            } else {//change coupling type to LS
                v.coupling = "LS";
            }
            if (v.playAnimation == false) {
                update_graph();
            }
        }

        function pause_play() {
            update_graph();
        }

        function display_cones() {
            if (v.playAnimation == false) {
                update_graph();
            }
        }

        
        function am_len(qnumber) {
            //Returns the length of an angular momentum vector with given quantum number
            return Math.sqrt(qnumber*(qnumber+1));
        }
        
        function draw_arrow(obj, pointsx, pointsy, pointsz, color) {
            // Returns an arrowhead based on an inputted line
            let x = pointsx[1],                     //xyz position of arrow
                y = pointsy[1],
                z = pointsz[1],
                u = 0.2*(pointsx[1] - pointsx[0]),  //uvw direction of arrow
                v = 0.2*(pointsy[1] - pointsy[0]),
                w = 0.2*(pointsz[1] - pointsz[0]);
            obj.push({
                type: "cone",
                colorscale: [[0, color],[1, color]],
                x: [x],
                y: [y],
                z: [z],
                u: [u],
                v: [v],
                w: [w],
                sizemode: "absolute",
                sizeref: 0.3*Math.sqrt(Vector.fromArray([x,y,z]).length()),
                showscale: false,
            });
        }

        function draw_cones(L,S,J,obj) {
            /* 
            Note: mesh3d does not support legendgroup!
            This means it is necessary to have a button hide/show cones,
            since clicking on the legend will not do anything...
            */
            if (v.cones == true) {
                var cone_opacity = 0.4;
            } else {
                cone_opacity = 0;
            }

            let L_cone = {x: [], y: [], z: []},
                S_cone = {x: [], y: [], z: []},
                J_cone = {x: [], y: [], z: []},
                Z = new Vector(0,0,1);

            for (let i=0; i<50; i++) {
                L_cone.x.push(0); L_cone.y.push(0); L_cone.z.push(0);
                S_cone.x.push(0); S_cone.y.push(0); S_cone.z.push(0);
                J_cone.x.push(0); J_cone.y.push(0); J_cone.z.push(0);

                L_cone.x.push(L.linearTransform(get_rot_matrix(i,J))[0]);
                L_cone.y.push(L.linearTransform(get_rot_matrix(i,J))[1]);
                L_cone.z.push(L.linearTransform(get_rot_matrix(i,J))[2]);

                S_cone.x.push(S.linearTransform(get_rot_matrix(i,J))[0]);
                S_cone.y.push(S.linearTransform(get_rot_matrix(i,J))[1]);
                S_cone.z.push(S.linearTransform(get_rot_matrix(i,J))[2]);

                J_cone.x.push(J.linearTransform(get_rot_matrix(i,Z))[0]);
                J_cone.y.push(J.linearTransform(get_rot_matrix(i,Z))[1]);
                J_cone.z.push(J.linearTransform(get_rot_matrix(i,Z))[2]);
            }
            obj.push(    
                {//L vector cone
                    type: 'mesh3d',
                    color: '#0080FF',
                    opacity: cone_opacity,
                    x: L_cone.x,
                    y: L_cone.y,
                    z: L_cone.z,
                },
                {//S vector cone
                    type: 'mesh3d',
                    color: '#50C878',
                    opacity: cone_opacity,
                    x: S_cone.x,
                    y: S_cone.y,
                    z: S_cone.z,
                },
                {//J vector cone
                    type: 'mesh3d',
                    color: '#9400D3',
                    opacity: cone_opacity,
                    x: J_cone.x,
                    y: J_cone.y,
                    z: J_cone.z,
                },
            );
        }

        function get_rot_matrix(angle, vector){//Returns rotation matrix about an arbitrary axis
            let [x,y,z] = vector.unit().toArray(),
                c = Math.cos(angle),
                s = Math.sin(angle),
                C = 1-c,
                Q = matrix([[x*x*C+c, x*y*C-z*s, x*z*C+y*s],[x*y*C+z*s, y*y*C+c, y*z*C-x*s],[x*z*C-y*s, y*z*C+x*s, z*z*C+c]]);
            
            return Q;
        }

        function get_components(V, len1, len2, z, phi = 0) {
            /*
            V is either a vector or a magnitude of the main vector.
            len1 and len2 are the magnitudes of the component vectors.
            z is the z-component of V.
            Returns the main vector and the component vectors.
            angle1 opposite len1 and angle2 opposite len2 in the V-len1-len2 triangle.
            */
            if (typeof V == "number") {
                var theta = Math.acos(z/V);
                V = new Vector(V*Math.sin(theta)*Math.cos(phi), V*Math.sin(theta)*Math.sin(phi), V*Math.cos(theta));
            } else if (V instanceof Vector) {
                    theta = Math.acos(z/V.length());
                    phi = Math.atan2(V.y, V.x);
            }
            let angle1 = Math.acos((V.length()*V.length()-len1*len1+len2*len2)/(2*V.length()*len2)),
                angle2 = Math.acos((V.length()*V.length()+len1*len1-len2*len2)/(2*V.length()*len1)),
                comp1 = new Vector(len1*Math.sin(theta+angle2)*Math.cos(phi), len1*Math.sin(theta+angle2)*Math.sin(phi), len1*Math.cos(theta+angle2)),
                comp2 = new Vector(len2*Math.sin(theta-angle1)*Math.cos(phi), len2*Math.sin(theta-angle1)*Math.sin(phi), len2*Math.cos(theta-angle1));

            return [V,comp1,comp2];
        }

        function get_data() {
            let data = [],
                mj = v.mjChoice,
                freqJ = 1/20,   //freq that J vector rotates around Z
                freqLS = 1/10,  //freq that L and S vectors rotate around J
                freqComp = 1/5; //freq that L and S component vectors rotate around L and S
            
            if (v.electrons == 1) {//only use values from activated switches
                var s = v.sChoice,
                    l = v.lChoice;
            } else {//use values from both switches
                var s1 = v.s1Choice,
                    l1 = v.l1Choice,
                    s2 = v.s2Choice,
                    l2 = v.l2Choice;
                s = s1+s2;
                l = l1+l2;
            }


            console.log("made it here")
            
            var L,J,S,Jx,Jy,Jz;
            if (v.coupling == "LS") {//plot L and S components to J
                //Note that coupling = "LS" if electrons = 1, so this also triggers if there is only one electron
                
                [J,L,S] = get_components(am_len(l+s), am_len(l), am_len(s), mj, freqJ*t);
                [Jx,Jy,Jz] = J.toArray(3);
                
                

                var [Lx,Ly,Lz] = L.linearTransform(get_rot_matrix(freqLS*t, J));
                var [Sx,Sy,Sz] = S.linearTransform(get_rot_matrix(freqLS*t, J));
                L = Vector.fromArray([Lx,Ly,Lz]),       // eslint-disable-line no-redeclare
                S = Vector.fromArray([Sx,Sy,Sz]);       // eslint-disable-line no-redeclare

                
                data.push(
                    {//L vector
                        name: 'Angular momentum',
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#0080FF'},
                        legendgroup: 'l',
                        showlegend: true,
                        x: [0, Lx],
                        y: [0, Ly],
                        z: [0, Lz],
                    },        
                    {//S vector
                        name: 'Spin',
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#50C878'},
                        legendgroup: 's',
                        showlegend: true,
                        x: [0, Sx],
                        y: [0, Sy],
                        z: [0, Sz],
                    },
                );
                //draw arrowtips for L and S vectors
                draw_arrow(data, [0, Lx], [0, Ly], [0, Lz], '#0080FF');
                draw_arrow(data, [0, Sx], [0, Sy], [0, Sz], '#50C878');

                console.log("L is this");
                console.log(L);


                if (v.electrons == 2) {//plot components to L and S
                    console.log("in if statement");
                    console.log(L);
                    console.log("displayed")

                    var L1,L2,S1,S2;
                    [L,L1,L2] = get_components(L, am_len(l1), am_len(l2), Lz);
                    [S,S1,S2] = get_components(S, am_len(s1), am_len(s2), Sz);
                    var [L1x,L1y,L1z] = L1.linearTransform(get_rot_matrix(freqComp*t, L)),
                        [L2x,L2y,L2z] = L2.linearTransform(get_rot_matrix(freqComp*t, L)),
                        [S1x,S1y,S1z] = S1.linearTransform(get_rot_matrix(freqComp*t, S)),
                        [S2x,S2y,S2z] = S2.linearTransform(get_rot_matrix(freqComp*t, S));
                    
                    
                    console.log("past checkpoint");


                    data.push(
                        {//L1 vector
                            type: 'scatter3d',
                            mode: 'lines',
                            line: {width: 10, dash: 'solid', color: '#9FCFFF'},
                            legendgroup: 'l',
                            showlegend: false,
                            x: [0, L1x],
                            y: [0, L1y],
                            z: [0, L1z]
                        },
                        {//L2 vector
                            type: 'scatter3d',
                            mode: 'lines',
                            line: {width: 10, dash: 'solid', color: '#9FCFFF'},
                            legendgroup: 'l',
                            showlegend: false,
                            x: [0, L2x],
                            y: [0, L2y],
                            z: [0, L2z]
                        },
                        {//S1 vector
                            type: 'scatter3d',
                            mode: 'lines',
                            line: {width: 10, dash: 'solid', color: '#A8E4BB'},
                            legendgroup: 's',
                            showlegend: false,
                            x: [0, S1x],
                            y: [0, S1y],
                            z: [0, S1z]
                        },
                        {//S2 vector
                            type: 'scatter3d',
                            mode: 'lines',
                            line: {width: 10, dash: 'solid', color: '#A8E4BB'},
                            legendgroup: 's',
                            showlegend: false,
                            x: [0, S2x],
                            y: [0, S2y],
                            z: [0, S2z]
                        },
                    );
                    //draw arrowtips to component vectors
                    draw_arrow(data, [0, L1x], [0, L1y], [0, L1z], '#9FCFFF');
                    draw_arrow(data, [0, L2x], [0, L2y], [0, L2z], '#9FCFFF');
                    draw_arrow(data, [0, S1x], [0, S1y], [0, S1z], '#A8E4BB');
                    draw_arrow(data, [0, S2x], [0, S2y], [0, S2z], '#A8E4BB');

                } else {//draw cones if there is only one electron
                    draw_cones(L,S,J,data);
                }
            } else {//draw arrows for jj-coupling
                [J,J1,J2] = get_components(am_len(l+s), am_len(l1+s1), am_len(l2+s2), mj, freqJ*t);
                [Jx,Jy,Jz] = J.toArray(3);
                var [J1x,J1y,J1z] = J1.linearTransform(get_rot_matrix(freqLS*t, J)),
                    [J2x,J2y,J2z] = J2.linearTransform(get_rot_matrix(freqLS*t, J)),

                    //Calculate J1 and J2 component vectors
                    J1 = Vector.fromArray([J1x,J1y,J1z]),
                    J2 = Vector.fromArray([J2x,J2y,J2z]),
                    [J1,L1,S1] = get_components(J1, am_len(l1), am_len(s1), J1z), // eslint-disable-line no-redeclare
                    [J2,L2,S2] = get_components(J2, am_len(l2), am_len(s2), J2z), // eslint-disable-line no-redeclare
                    [L1x,L1y,L1z] = L1.linearTransform(get_rot_matrix(freqComp*t, J1)), // eslint-disable-line no-redeclare
                    [L2x,L2y,L2z] = L2.linearTransform(get_rot_matrix(freqComp*t, J2)), // eslint-disable-line no-redeclare
                    [S1x,S1y,S1z] = S1.linearTransform(get_rot_matrix(freqComp*t, J1)), // eslint-disable-line no-redeclare
                    [S2x,S2y,S2z] = S2.linearTransform(get_rot_matrix(freqComp*t, J2)); // eslint-disable-line no-redeclare

                data.push(
                    {//J1 vector
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#CA80E9'},
                        showlegend: false,
                        legendgroup: 'j',
                        x: [0, J1x],
                        y: [0, J1y],
                        z: [0, J1z],
                    },        
                    {//J2 vector
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#CA80E9'},
                        showlegend: false,
                        legendgroup: 'j',
                        x: [0, J2x],
                        y: [0, J2y],
                        z: [0, J2z],
                    },
                );
                draw_arrow(data, [0, J1x], [0, J1y], [0, J1z], '#CA80E9');
                draw_arrow(data, [0, J2x], [0, J2y], [0, J2z], '#CA80E9');

                data.push(
                    {//L1 vector
                        name: 'Orbital angular momentum',
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#9FCFFF'},
                        legendgroup: 'l',
                        showlegend: true,
                        x: [0, L1x],
                        y: [0, L1y],
                        z: [0, L1z]
                    },
                    {//L2 vector
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#9FCFFF'},
                        legendgroup: 'l',
                        showlegend: false,
                        x: [0, L2x],
                        y: [0, L2y],
                        z: [0, L2z]
                    },
                    {//S1 vector
                        name: 'Spin',
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#A8E4BB'},
                        legendgroup: 's',
                        showlegend: true,
                        x: [0, S1x],
                        y: [0, S1y],
                        z: [0, S1z]
                    },
                    {//S2 vector
                        type: 'scatter3d',
                        mode: 'lines',
                        line: {width: 10, dash: 'solid', color: '#A8E4BB'},
                        legendgroup: 's',
                        showlegend: false,
                        x: [0, S2x],
                        y: [0, S2y],
                        z: [0, S2z]
                    },
                    
                );
                //draw arrowtips
                draw_arrow(data, [0, L1x], [0, L1y], [0, L1z], '#9FCFFF');
                draw_arrow(data, [0, L2x], [0, L2y], [0, L2z], '#9FCFFF');
                draw_arrow(data, [0, S1x], [0, S1y], [0, S1z], '#A8E4BB');
                draw_arrow(data, [0, S2x], [0, S2y], [0, S2z], '#A8E4BB');
            }
            
            plt.layout.scene.xaxis.range = [-J.length(), J.length()];
            plt.layout.scene.yaxis.range = [-J.length(), J.length()];
            plt.layout.scene.zaxis.range = [-J.length(), J.length()];

            data.push(
                {//J vector
                    name: 'Total angular momentum',
                    type: 'scatter3d',
                    mode: 'lines',
                    line: {width: 10, dash: 'solid', color: '#9400D3'},
                    legendgroup: 'j',
                    x: [0, Jx],
                    y: [0, Jy],
                    z: [0, Jz],
                },
            );
            draw_arrow(data, [0, Jx], [0, Jy], [0, Jz], '#9400D3');

            return data;
        }

        function initial() {//Plots the initial data and shifts from loading to container       
            Plotly.purge('graph')
            Plotly.newPlot('graph', get_data(), plt.layout)
            
            update_graph();
        }

        function update_graph() {//Updates the data
            Plotly.animate('graph', 
                {data: get_data()},
                {
                    fromcurrent: true,
                    frame: {duration: 0, redraw: true,},
                    transition: {duration: 0},
                    mode: 'next', //Gives Uncaught errors with 'next' and 'immediate', but runs much slower with 'afterall'
                });

            if (v.playAnimation == true) {
                t++;
            
            }
        }


        function animate(){
            requestAnimationFrame(animate);

            if (v.electronChanged==true){
                change_electrons();
                v.electronChanged=false;
            }


            if(v.stopStartChanged==true){
                pause_play();
                v.stopStartChanged=false;
            }

            if(v.stopStartChanged==true){
                pause_play();
                v.stopStartChanged=false;
            }

            if(v.playAnimation==true){
                update_graph();
            }

            if(v.graphUpdate==true){
                update_graph();
                v.graphUpdate=false;
            }

            
        }
        
        initial();
        animate();

    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
.column {
  float: left;
  width: 50%;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>