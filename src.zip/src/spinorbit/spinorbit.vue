<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="2">
            
            <template #hotspots>
                <iv-pane position="left" format="push" :width=28>
                    <iv-sidebar-content :showPagination="true">
                                                
                        <iv-sidebar-section title="Theory" icon="microscope" >
                            <p>
                                For an electron in an atom, the angular momentum <iv-equation-box :stylise="false" equation="\mathbf{L}"/>
                                and spin <iv-equation-box :stylise="false" equation="\mathbf{S}"/> couple to form a constant total 
                                angular momentum <iv-equation-box :stylise="false" equation="\mathbf{J}"/>. Without a spin-orbit 
                                interaction the quantum numbers <iv-equation-box :stylise="false" equation="m_l"/> and 
                                <iv-equation-box :stylise="false" equation="m_s"/> are degenerate. But now the energy levels depend 
                                on the relative orientation of <iv-equation-box :stylise="false" equation="\mathbf{L}"/> and 
                                <iv-equation-box :stylise="false" equation="\mathbf{S}"/>, so <iv-equation-box :stylise="false" equation="m_l"/> 
                                and <iv-equation-box :stylise="false" equation="m_s"/> are no longer good quantum numbers. Instead, 
                                the operator <iv-equation-box :stylise="false" equation="\mathbf{\hat{J}} "/> gives a new quantum 
                                number <iv-equation-box :stylise="false" equation="j"/>. Similarly, the operator 
                                <iv-equation-box :stylise="false" equation="\mathbf{\hat{J}}_z  "/> gives rise to a new quantum 
                                number <iv-equation-box :stylise="false" equation="m_j"/>. Hence, we obtain a set of operators:
                            </p>
                            <p>
                                <ul>
                                    <li>
                                        <iv-equation-box :stylise="true" equation="\mathbf{\hat{S}}^2\mathbf{\Psi}=\hbar^2 s(s+1)\mathbf{\Psi} \\ \mathbf{\hat{S}}_z\mathbf{\Psi}=\hbar m_s\mathbf{\Psi}"/>
                                        <br>
                                        <iv-equation-box :stylise="false" equation="m_s = -s,\dots ,s"/>
                                    </li>
                                    <li>
                                        <iv-equation-box :stylise="true" equation="\mathbf{\hat{L}}^2\mathbf{\Psi}=\hbar^2 l(l+1)\mathbf{\Psi} \\ \mathbf{\hat{L}}_z\mathbf{\Psi}=\hbar m_l\mathbf{\Psi}"/>
                                        <br>
                                        <iv-equation-box :stylise="false" equation="m_l = -l,\dots ,l "/>
                                    </li>
                                    <li>
                                        <iv-equation-box :stylise="true" equation="\mathbf{\hat{J}}^2\mathbf{\Psi}=\hbar^2 j(j+1)\mathbf{\Psi} \\ \mathbf{\hat{J}}_z\mathbf{\Psi}=\hbar m_j\mathbf{\Psi}"/>
                                        <br>
                                        <iv-equation-box :stylise="false" equation="m_j = -j,\dots ,j"/>
                                    </li>    
                                </ul>
                            </p>

                            
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Instructions" icon="question" theme="Lime" >
                            <p>
                                Open the quantum numbers tab to change the spin and orbital angular momentum quantum numbers and their projections.
                            </p>
                            <p>    
                                Predict what will happen to the total angular momentum quantum number, <iv-equation-box :stylise="false" equation="j"/>, 
                                and its projection, <iv-equation-box :stylise="false" equation="m_j"/>. Do
                                the values in the top right box match your expectations? 
                            </p>
                        </iv-sidebar-section>
                                            
                    </iv-sidebar-content>
                </iv-pane>


                <iv-toggle-hotspot :glass=true position="bottom" title="Quantum numbers" style=" z-index: 2;">
                    
                    <iv-toggle-advance id="toggle4" :width=toggleWidth :togglesDisabled=disableList2 :modes=modeNames4 :initialModeIndex=3 @toggleswitched="mlChange" position="centre"></iv-toggle-advance>
                    <label for="toggle4"> Magnetic quantum number, m_l</label>    

                    <iv-toggle-advance id="toggle3" :width=toggleWidth :modes=modeNames3 :initialModeIndex=0 @toggleswitched="lChange" position="centre"></iv-toggle-advance>
                    <label for="toggle3"> Orbital angular momentum quantum number, l </label>

                    <iv-toggle-advance id="toggle2" :width=toggleWidth :togglesDisabled=disableList1 :modes=modeNames2 :initialModeIndex=3 @toggleswitched="msChange" position="centre"></iv-toggle-advance>
                    <label for="toggle2"> Secondary spin quantum number, m_s</label>    

                    <iv-toggle-advance id="toggle1" :width=toggleWidth :modes=modeNames1 :initialModeIndex=0 @toggleswitched="sChange" position="centre"></iv-toggle-advance>
                    <label for="toggle1"> Spin quantum number, s </label>
                        
                </iv-toggle-hotspot>

                <iv-fixed-hotspot position="topright" style=" z-index: 2;" >
                    <p>
                        Total angular momentum quantum number, j = {{display1}}
                    </p>
                    <p>
                        Secondary total angular momentum quantum number, m_j = {{display2}}
                    </p>
                </iv-fixed-hotspot>

            </template>
            
            
            <div class="iv-welcome-message">
                <!-- Graph -->
                <div id = "graph" />
            </div>
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js';
import Plotly from 'plotly.js/dist/plotly.min.js';
import {matrix,multiply} from 'mathjs';
export default {
    name:"spinorbit",
    data(){
        return {
            pageName:"Addition of Angular Momenta",
            vue_config,
            graphUpdate: false,
            sChoice:1/2,
            msChoice:1/2,
            lChoice:0,
            mlChoice:0,
            disableList1: [true, false, true, false, true],
            disableList2: [true,true, true, false, true, true,true],
            display1:0,
            display2:0
        }
    },
    props:{
        modeNames1:{default: ["1/2", "1"]},
        modeNames2:{default: ["-1","-1/2","0","1/2","1"]},
        modeNames3:{default: ["0","1","2","3"]},
        modeNames4:{default: ["-3","-2","-1","0","1","2","3"]},
        toggleWidth:{default: '45px'}
    },
    methods:{
        sChange(e){
            this.sChoice = (e +1) /2;
            this.graphUpdate = true;

            if(e == 0){
                this.disableList1 = [true, false, true, false, true];             
            }
            if(e == 1){
                this.disableList1 = [false, true, false, true, false];          
            }

            console.log("s");
            console.log(this.sChoice)
        },

        msChange(e){                        
            this.msChoice = (e - 2)/2;
            this.graphUpdate = true;   

            console.log("ms");
            console.log(this.msChoice)
        },

        lChange(e){
            this.lChoice = e;
            this.graphUpdate = true;

            if(e == 0){
                this.disableList2 = [true,true, true, false, true, true,true];             
            }
            if(e == 1){
                this.disableList2 = [true,true, false, false, false, true,true];          
            }
            if(e == 2){
                this.disableList2 = [true,false, false, false, false, false,true];             
            }
            if(e == 3){
                this.disableList2 = [false,false, false, false, false, false,false];          
            }

            console.log("l");
            console.log(this.lChoice)
        },

        mlChange(e){                        
            this.mlChoice = e - 3;
            this.graphUpdate = true;   

            console.log("ml");
            console.log(this.mlChoice)
        },
    },

    mounted(){
        let v=this;

        function Vector(x, y, z) {
            this.x = x || 0;
            this.y = y || 0;
            this.z = z || 0;
        }

        Vector.prototype = {
            negative: function() {
                return new Vector(-this.x, -this.y, -this.z);
            },
            add: function(v) {
                if (v instanceof Vector) return new Vector(this.x + v.x, this.y + v.y, this.z + v.z);
                else return new Vector(this.x + v, this.y + v, this.z + v);
            },
            subtract: function(v) {
                if (v instanceof Vector) return new Vector(this.x - v.x, this.y - v.y, this.z - v.z);
                else return new Vector(this.x - v, this.y - v, this.z - v);
            },
            multiply: function(v) {
                if (v instanceof Vector) return new Vector(this.x * v.x, this.y * v.y, this.z * v.z);
                else return new Vector(this.x * v, this.y * v, this.z * v);
            },
            divide: function(v) {
                if (v instanceof Vector) return new Vector(this.x / v.x, this.y / v.y, this.z / v.z);
                else return new Vector(this.x / v, this.y / v, this.z / v);
            },
            equals: function(v) {
                return this.x == v.x && this.y == v.y && this.z == v.z;
            },
            dot: function(v) {
                return this.x * v.x + this.y * v.y + this.z * v.z;
            },
            cross: function(v) {
                return new Vector(
                this.y * v.z - this.z * v.y,
                this.z * v.x - this.x * v.z,
                this.x * v.y - this.y * v.x
                );
            },
            length: function() {
                return Math.sqrt(this.dot(this));
            },
            unit: function() {
                return this.divide(this.length());
            },
            min: function() {
                return Math.min(Math.min(this.x, this.y), this.z);
            },
            max: function() {
                return Math.max(Math.max(this.x, this.y), this.z);
            },
            toAngles: function() {
                return {
                theta: Math.atan2(this.z, this.x),
                phi: Math.asin(this.y / this.length())
                };
            },
            angleTo: function(a) {
                return Math.acos(this.dot(a) / (this.length() * a.length()));
            },
            toArray: function(n) {
                return [this.x, this.y, this.z].slice(0, n || 3);
            },
            clone: function() {
                return new Vector(this.x, this.y, this.z);
            },
            init: function(x, y, z) {
                this.x = x; this.y = y; this.z = z;
                return this;
            },
            //Custom functions, not in original file!
            vecToMatrix: function() {
                return matrix([[this.x], [this.y], [this.z]]);
            },
            //Multiplies vector object with a math.matrix object
            linearTransform: function(M) {
                return [].concat.apply([], multiply(M, this.vecToMatrix())["_data"]);
            },
            //Projects onto another vector
            project: function(v) {
                return v.unit().multiply(this.dot(v.unit()));
            },
        };

        Vector.negative = function(a, b) {
            b.x = -a.x; b.y = -a.y; b.z = -a.z;
            return b;
        };
        Vector.add = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x + b.x; c.y = a.y + b.y; c.z = a.z + b.z; }
            else { c.x = a.x + b; c.y = a.y + b; c.z = a.z + b; }
            return c;
        };
        Vector.subtract = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x - b.x; c.y = a.y - b.y; c.z = a.z - b.z; }
            else { c.x = a.x - b; c.y = a.y - b; c.z = a.z - b; }
            return c;
        };
        Vector.multiply = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x * b.x; c.y = a.y * b.y; c.z = a.z * b.z; }
            else { c.x = a.x * b; c.y = a.y * b; c.z = a.z * b; }
            return c;
        };
        Vector.divide = function(a, b, c) {
            if (b instanceof Vector) { c.x = a.x / b.x; c.y = a.y / b.y; c.z = a.z / b.z; }
            else { c.x = a.x / b; c.y = a.y / b; c.z = a.z / b; }
            return c;
        };
        Vector.cross = function(a, b, c) {
            c.x = a.y * b.z - a.z * b.y;
            c.y = a.z * b.x - a.x * b.z;
            c.z = a.x * b.y - a.y * b.x;
            return c;
        };
        Vector.unit = function(a, b) {
            var length = a.length();
            b.x = a.x / length;
            b.y = a.y / length;
            b.z = a.z / length;
            return b;
        };
        Vector.fromAngles = function(theta, phi) {
            return new Vector(Math.cos(theta) * Math.cos(phi), Math.sin(phi), Math.sin(theta) * Math.cos(phi));
        };
        Vector.randomDirection = function() {
            return Vector.fromAngles(Math.random() * Math.PI * 2, Math.asin(Math.random() * 2 - 1));
        };
        Vector.min = function(a, b) {
            return new Vector(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z));
        };
        Vector.max = function(a, b) {
            return new Vector(Math.max(a.x, b.x), Math.max(a.y, b.y), Math.max(a.z, b.z));
        };
        Vector.lerp = function(a, b, fraction) {
            return b.subtract(a).multiply(fraction).add(a);
        };
        Vector.fromArray = function(a) {
            return new Vector(a[0], a[1], a[2]);
        };
        Vector.angleBetween = function(a, b) {
            return a.angleTo(b);
        };

        const
        plt = {//layout of graph
            layout : {
                legend: {x: 0.2, y: -0.2, orientation: 'h'},
                autosize: true,
                font: {
                    family: "Fira Sans",
                    size: 16,
                },
                xaxis: {
                    title: 'L<sub>xy',
                    titlefont: {
                        family: "Fira Sans",
                        size: 22,
                        color: '#7f7f7f'
                    },
                    range: [-2,2],
                    tickvals: [-4,-3,-2,-1,0,1,2,3,4],
                    ticktext: ["-4\u0127","-3\u0127","-2\u0127","-\u0127",0,"\u0127","2\u0127","3\u0127","4\u0127"],
                    tickfont: {
                    family: "Fira Sans",
                    size: 18,
                    color: 'black'
                    },
                },
                yaxis: {
                    title: 'L<sub>z',
                    titlefont: {
                        family: "Fira Sans",
                        size: 22,
                        color: '#7f7f7f'
                    },
                    range: [-2,2],
                    tickvals: [-4,-3,-2,-1,0,1,2,3,4],
                    ticktext: ["-4\u0127","-3\u0127","-2\u0127","-\u0127",0,"\u0127","2\u0127","3\u0127","4\u0127"],
                    tickfont: {
                    family: "Fira Sans",
                    size: 18,
                    color: 'black'
                    },
                },
                margin: {
                    l: 50, r: 20, b: 0, t: 30, pad: 0,
                },
                hovermode: false,
            }
        };

        function draw_arrowtips(obj, x, y, angle, length_ratio, color, legendgroup) {
            /* rotates the vector -angle and +angle to make the two tips,
            scales down to length_ratio and pushes to obj */
            
            let vec1 = new Vector(Math.cos(angle),Math.sin(angle),0).multiply(x).add(new Vector(-Math.sin(angle),Math.cos(angle),0).multiply(y)).multiply(length_ratio),
                vec2 = new Vector(Math.cos(-angle),Math.sin(-angle),0).multiply(x).add(new Vector(-Math.sin(-angle),Math.cos(-angle),0).multiply(y)).multiply(length_ratio);
            
            obj.push({x: [x, x+vec1.x], y: [y, y+vec1.y], mode: "lines", line: {width: 3, color: color}, legendgroup: legendgroup, showlegend: false});
            obj.push({x: [x, x+vec2.x], y: [y, y+vec2.y], mode: "lines", line: {width: 3, color: color}, legendgroup: legendgroup, showlegend: false});        
        }

        function draw_circle(obj, r, color, legendgroup) {//draws the circle
            let circle = {x: [], y: []},
                res = 100;                  //resolution of circle

            for (let phi=0; phi<=2*res; phi++) {
                circle.x.push(r*Math.sin(phi*Math.PI/res));
                circle.y.push(r*Math.cos(phi*Math.PI/res));
            }

            obj.push({//circle with radius the length of S
                type: "scatter",
                mode: "lines",
                line: {
                    width: 2,
                    color: color
                },
                x: circle.x,
                y: circle.y,
                legendgroup: legendgroup,
                showlegend: false
            });
        }

        function get_data() {
            let data = [],
                ms = v.msChoice,
                ml = v.mlChoice,
                s = v.sChoice,
                l = v.lChoice,
                xs = Math.sqrt(s*(s+1)-Math.pow(ms, 2)),
                xl = Math.sqrt(l*(l+1)-Math.pow(ml, 2)),
                mj = ms + ml,
                j = s + l;                            

            if (xs >= xl) {//position of j vector text
                var tj = -0.3;
            } else {
                tj = 0.3;
            }

            //Spin vector elements
            data.push({name: "Spin", x: [0, xs], y: [0, ms], mode: "lines", line: {width: 3, color: '50C878'}, legendgroup: "s"});
            draw_arrowtips(data, xs, ms, 7*Math.PI/8, 0.2, '50C878', 's');
            draw_circle(data, Math.sqrt(s*(s+1)), '50C878', 's');
            data.push({x: [0, xs], y: [ms, ms], mode: "lines", line: {width: 3, dash: "dash", color: '50C878'}, legendgroup: "s", showlegend: false});
            data.push({x: [+xs +0.3], y: [ms], mode: "text", text: 'm<sub>s', textfont: {size: 20, color: '50C878'}, legendgroup: "s", showlegend: false});

            //Angular momentum vector elements
            data.push({name: "Orbital angular momentum", x: [0,-xl], y: [0, ml], mode: "lines", line: {width: 3, color: '0080FF'}, legendgroup: "l"});
            draw_arrowtips(data, -xl, ml, 7*Math.PI/8, 0.2, '0080FF', 'l');
            draw_circle(data, Math.sqrt(l*(l+1)), '0080FF', 'l');
            data.push({x: [0, -xl], y: [ml, ml], mode: "lines", line: {width: 3, dash: "dash", color: '0080FF'}, legendgroup: "l", showlegend: false});
            data.push({x: [-xl -0.3], y: [ml], mode: "text", text: 'm<sub>l', textfont: {size: 20, color: '0080FF'}, legendgroup: "l", showlegend: false});

            //Total angular momentum vector elements
            data.push({name: "Total angular momentum", x: [0,xs-xl], y: [0, mj], mode: "lines", line: {width: 3, color: '9400D3'}, legendgroup: "j"});
            draw_arrowtips(data, xs-xl, mj, 7*Math.PI/8, 0.2, '9400D3', 'j');
            data.push({x: [0, xs-xl], y: [mj, mj], mode: "lines", line: {width: 3, dash: "dash", color: '9400D3'}, legendgroup: "j", showlegend: false});
            data.push({x: [tj], y: [mj], mode: "text", text: 'm<sub>j', textfont: {size: 20, color: '9400D3'}, legendgroup: "j", showlegend: false});
            

            //Change the printed mj and j values
            v.display1=j;
            v.display2=mj;


            return data;
        }

        function rescale_range() {//change the range of the plot
            let ml = v.mlChoice,
                l = v.lChoice,           
                xl = Math.sqrt(l*(+l+1)-Math.pow(ml, 2));

            if (xl >= 2 || l >= 2) {
                plt.layout.xaxis.range = [-5, 5];
                plt.layout.yaxis.range = [-5, 5];
            } else {
                plt.layout.xaxis.range = [-2.5, 2.5];
                plt.layout.yaxis.range = [-2.5, 2.5];
            }
        }

        function initial() {
            Plotly.purge("graph")
            Plotly.newPlot('graph', get_data(), plt.layout)
        }

        function update_graph() {
            rescale_range();

            Plotly.animate("graph", {
                data: get_data(),
                layout: plt.layout
            }, {
                transition: {
                    duration: 500,
                    easing: 'cubic-in-out'
                }
            });
        }

        function animate(){
            requestAnimationFrame(animate);

            if (v.graphUpdate==true){
                update_graph();
                v.graphUpdate=false;
            }
         
        }
        
        initial();
        animate();

    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
.column {
  float: left;
  padding: 10px;
  height: 300px; /* Should be removed. Only for demonstration */
}

.left {
  width: 30vw;
}

.right {
  width: 30vw;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>